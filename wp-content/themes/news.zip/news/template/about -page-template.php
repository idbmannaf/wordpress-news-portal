<?php
/*
*Template Name: About Page Template
*/
?>

<?php get_header() ?>
<body <?php body_class(); ?>>
<?php get_template_part('about-hero') ?>

<?php get_footer() ?>
