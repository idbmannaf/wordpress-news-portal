<?php get_header() ?>

<body <?php body_class(); ?>>
	<?php get_template_part('hero') ?>
	<div class="container">
		<div class="row">
			<div class="col-md-8 m-auto">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
						<h1><?php the_title() ?></h1>
						<?php the_content() ?>
						<?php echo get_the_content() ?>
					<?php endwhile; ?>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php get_footer() ?>